# Quality Swarms by AethDesign

This download contains the Swarms agent instruction module, with the shared quality foundation included once.

This is an instruction-only download. It does not include the executable toolkit, project templates, or bootstrap command.

Source and toolkit: https://github.com/aethirex-ai/quality-code . Setup: https://github.com/aethirex-ai/quality-code/blob/main/docs/GETTING_STARTED.md . The Code module expects MAP.md, TESTING.md and the local quality CLI; initialize/adopt the project with the toolkit and the same module selection before implementation. Visuals and Swarms can use existing project tools and requirements.

Do not stack multiple downloaded AGENTS.md packs. Choose one combined selection. For a project that needs the executable toolkit, use the root repository CLI to initialize or adopt it, or to change an existing selection. For example: `python3 scripts/quality_code.py upgrade /path/to/project --modules swarms`. The CLI manages the AGENTS.md block while preserving user content.
